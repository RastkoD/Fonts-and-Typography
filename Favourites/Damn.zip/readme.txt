License: Creative Commons Attribution 4.0 International (CC BY 4.0)

https://creativecommons.org/licenses/by/4.0/

The only condition for the free use of the font is an indication of authorship in the form:
(Type name) developed by (student’s name and surname) at HSE ART AND DESIGN SCHOOL (in English).

Единственное условие бесплатного использования шрифта — это указание авторства в виде: 
(Название шрифта) разработан (имя и фамилия студента в родительном падеже) в Школе дизайна НИУ ВШЭ (на русском языке)

https://portfolio.hse.ru/Student/11024

https://hsedesignlab.ru/hsefonts