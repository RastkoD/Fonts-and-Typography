Giraffe is a font you can use in any of your projects for free. Though I'll be glad if you mention me as an author :) 

https://www.behance.net/uachernova